/*
 * Created on Jan 26, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package org.eclipse.iconexplorer.internal.tests;


import junit.framework.TestCase;

import org.eclipse.swt.graphics.Image;

import org.eclipse.iconexplorer.IImageFilter;
import org.eclipse.iconexplorer.internal.IconViewPart;

import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;

/**
 * Testing the icon explorer.
 */
public class IconExplorerTest extends TestCase {
	
	private IWorkbenchPage getActivePage() {
		IWorkbench workbench= PlatformUI.getWorkbench();
		IWorkbenchWindow window= workbench.getActiveWorkbenchWindow();
		return window.getActivePage();
	}
	
	private IconViewPart createViewPart(IWorkbenchPage page) {
		try {
			IWorkbenchPart createdPart= page.showView("org.eclipse.iconexplorer.iconview");
			if (createdPart instanceof IconViewPart)
				return (IconViewPart) createdPart;
		} catch (PartInitException e) {
			assertTrue(false);
		}
		return null;
	}
	
	public void testViewCreationAndActivation() {
		IWorkbenchPage page= getActivePage();
		IconViewPart createdPart= createViewPart(page);
		assertNotNull(createdPart);
		IWorkbenchPart part= page.getActivePart();
		assertEquals(createdPart, part);
	}
	
	public void testSafePlatform() {
		IWorkbenchPage page= getActivePage();
		IconViewPart createdPart= createViewPart(page);
		createdPart.setFilters(new IImageFilter[] {
			new IImageFilter() {
				public Image filter(Image image) {
					throw new NullPointerException();
				}
			}	
		});
		
		try {
			createdPart.refresh();
		} catch (NullPointerException x) {
			assertTrue(false);
		}
	}
}
