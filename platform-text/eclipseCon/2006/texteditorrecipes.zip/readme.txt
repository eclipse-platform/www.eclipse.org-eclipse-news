Text Editor Recipes
===================

Tutorial at EclipseCon 2006, Santa Clara, CA, USA

Presenters: Tom Eicher <tom_eicher@ch.ibm.com>
            Martin Aeschlimann <martin_aeschlimann@ch.ibm.com>


Table of Contents
-----------------

 /- readme.txt     - this file
 |- copying.html   - about copying the contents of this CD
 |- epl-v10.html   - the Eclipse Public Licence v. 1.0
 |- presentation/  - the tutorial slides
 |- steps/         - example plug-ins including source code
 |- icons/         - icons used in the tutorial
 |- eclipse/       - a selection recent eclipse builds

--

March 2006, Tom Eicher
