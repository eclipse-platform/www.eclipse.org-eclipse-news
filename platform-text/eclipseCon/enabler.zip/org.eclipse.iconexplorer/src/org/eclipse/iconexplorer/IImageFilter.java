/*******************************************************************************
 * Copyright (c) 2000, 2003 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.iconexplorer;

import org.eclipse.swt.graphics.Image;

/**
 * An image filter takes an image and returns a new image that represents the
 * input image after the application of the specific visual filter function.
 */
public interface IImageFilter {

	/**
	 * Returns a newly created image that represents the input image after
	 * having applied the visual filter function implemented by this filter. It
	 * can return <code>null</code> to indicate that the image is completely
	 * filtered away.
	 * 
	 * @param image the image to be filtered
	 * @return the filtered image
	 */
	Image filter(Image image);
}
