package org.eclipse.iconexplorer.internal;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;

import org.eclipse.jface.viewers.TableViewer;

import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.part.ViewPart;

/**
 * Icon view part for presenting the list of shared images used by the workbench.
 */
public class IconViewPart extends ViewPart {

	/** The viewer used by the view part. */
	private TableViewer fTableViewer;

	/**
	 * Creates a new icon view part.
	 */
	public IconViewPart() {
	}

	/*
	 * @see org.eclipse.ui.IWorkbenchPart#createPartControl(org.eclipse.swt.widgets.Composite)
	 */
	public void createPartControl(Composite parent)  {
		int flags= SWT.MULTI | SWT.H_SCROLL | SWT.V_SCROLL;
		fTableViewer= new TableViewer(parent, flags );
		fTableViewer.setContentProvider(new ContentProvider());
		fTableViewer.setLabelProvider(new LabelProvider());
		fTableViewer.setInput(ISharedImages.class);
	}

	/*
	 * @see org.eclipse.ui.IWorkbenchPart#setFocus()
	 */
	public void setFocus()  {
		Control control= fTableViewer.getControl();
		if (control != null && !control.isDisposed())
			control.setFocus();
	}
	
	/**
	 * Refreshes the list of images.
	 */
	public void refresh() {
		fTableViewer.refresh();
	}
}
