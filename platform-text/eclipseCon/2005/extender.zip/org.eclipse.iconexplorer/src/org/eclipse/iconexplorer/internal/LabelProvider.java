/*******************************************************************************
 * Copyright (c) 2000, 2003 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.iconexplorer.internal;

import java.lang.reflect.Field;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

import org.eclipse.swt.graphics.Image;

import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.PlatformUI;

/**
 * The label provider display names and images of the shared workbench images.
 */
public class LabelProvider extends org.eclipse.jface.viewers.LabelProvider {
	
	/*
	 * @see org.eclipse.jface.viewers.LabelProvider#getText(java.lang.Object)
	 */
	public String getText(Object element) {
		if (element instanceof Field) {
			Field field= (Field) element;
			return field.getName();
		}
		return element.toString();
	}
	
	/*
	 * @see org.eclipse.jface.viewers.LabelProvider#getImage(java.lang.Object)
	 */
	public Image getImage(Object element) {
		String imageName= ISharedImages.IMG_OBJ_ELEMENT;
		if (element instanceof Field) {
			Field field= (Field) element;
			try {
				imageName= (String) field.get(field);
			} catch (IllegalArgumentException e) {
				error(e, Messages.getString("LabelProvider.fieldError")); //$NON-NLS-1$
			} catch (IllegalAccessException e) {
				error(e, Messages.getString("LabelProvider.fieldError")); //$NON-NLS-1$
			}
		}
		return PlatformUI.getWorkbench().getSharedImages().getImage(imageName);
	}
	
	/**
	 * Handles the given throwable.
	 * 
	 * @param throwable the throwable
	 */
	private void error(Throwable throwable, String errorMessage) {
		Status s= new Status(IStatus.ERROR, IconExplorerPlugin.getId(), IStatus.ERROR, errorMessage, throwable);
		IconExplorerPlugin.getDefault().getLog().log(s);
	}
}
