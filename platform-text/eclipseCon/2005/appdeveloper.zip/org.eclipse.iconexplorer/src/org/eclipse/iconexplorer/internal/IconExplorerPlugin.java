package org.eclipse.iconexplorer.internal;

import org.eclipse.ui.plugin.AbstractUIPlugin;

/**
 * The icon explorer plug-in class.
 */
public class IconExplorerPlugin extends AbstractUIPlugin {
	
	/** The shared instance. */
	private static IconExplorerPlugin fgPlugin;
	
	/**
	 * Creates a new icon explorer plug-in.
	 */
	public IconExplorerPlugin() {
		super();
		fgPlugin = this;
	}

	/**
	 * Returns the shared instance.
	 * 
	 * @return the shared instance
	 */
	public static IconExplorerPlugin getDefault() {
		return fgPlugin;
	}
	
	/**
	 * Returns the id of the shared plug-in instance.
	 * 
	 * @return the id of the shared plug-in instance
	 */
	public static String getId() {
		return getDefault().getBundle().getSymbolicName();
	}
}
