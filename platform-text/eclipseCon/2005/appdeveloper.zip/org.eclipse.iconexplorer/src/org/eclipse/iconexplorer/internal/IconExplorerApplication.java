package org.eclipse.iconexplorer.internal;

import org.eclipse.core.runtime.IPlatformRunnable;

import org.eclipse.swt.widgets.Display;

import org.eclipse.ui.PlatformUI;

/**
 * The icon explorer application to be used as rich client platform
 * application.
 */
public class IconExplorerApplication implements IPlatformRunnable {
	
	/**
	 * Creates a new icon explorer application.
	 */
	public IconExplorerApplication() {
	}

	/*
	 * @see org.eclipse.core.runtime.IPlatformRunnable#run(java.lang.Object)
	 */
	public Object run(Object args) throws Exception {
		Display display = PlatformUI.createDisplay();
		int returnCode = PlatformUI.createAndRunWorkbench(display, new IconExplorerWorkbenchAdvisor());
		return new Integer(returnCode);
	}
}
