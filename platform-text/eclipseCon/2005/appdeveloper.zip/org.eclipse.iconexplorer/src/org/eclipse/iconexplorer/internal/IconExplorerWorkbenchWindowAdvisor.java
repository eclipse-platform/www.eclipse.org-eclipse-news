/*******************************************************************************
 * Copyright (c) 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.iconexplorer.internal;

import org.eclipse.ui.application.IWorkbenchWindowConfigurer;
import org.eclipse.ui.application.WorkbenchWindowAdvisor;

/**
 * The work bench advisor defining the appearance of the workbench window for
 * the icon explorer application.
 */
public class IconExplorerWorkbenchWindowAdvisor extends WorkbenchWindowAdvisor {

	/**
	 * Creates a new instance
	 * @param configurer the configurer
	 */
	public IconExplorerWorkbenchWindowAdvisor(IWorkbenchWindowConfigurer configurer) {
		super(configurer);
	}
	
	/*
	 * @see org.eclipse.ui.application.WorkbenchWindowAdvisor#postWindowOpen()
	 */
	public void postWindowOpen() {
		getWindowConfigurer().setTitle(Messages.getString("IconExplorerWorkbenchAdvisor.window.title")); //$NON-NLS-1$
	}
	
	/*
	 * @see org.eclipse.ui.application.WorkbenchWindowAdvisor#preWindowOpen()
	 */
	public void preWindowOpen() {
		getWindowConfigurer().setShowFastViewBars(false);
		getWindowConfigurer().setShowPerspectiveBar(false);
		getWindowConfigurer().setShowMenuBar(false);
		getWindowConfigurer().setShowProgressIndicator(false);
		getWindowConfigurer().setShowStatusLine(false);
		getWindowConfigurer().setShowCoolBar(false);
	}

}
