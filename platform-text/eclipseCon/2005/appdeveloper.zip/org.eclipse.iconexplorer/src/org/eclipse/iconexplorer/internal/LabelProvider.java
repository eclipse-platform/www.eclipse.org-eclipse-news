/*******************************************************************************
 * Copyright (c) 2000, 2003 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.iconexplorer.internal;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.ISafeRunnable;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Status;

import org.eclipse.swt.graphics.Image;

import org.eclipse.iconexplorer.IImageFilter;

import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.PlatformUI;

/**
 * The label provider display names and images of the shared workbench images.
 */
public class LabelProvider extends org.eclipse.jface.viewers.LabelProvider {
	
	private List fImageFilters;

	/*
	 * @see org.eclipse.jface.viewers.LabelProvider#getText(java.lang.Object)
	 */
	public String getText(Object element) {
		if (element instanceof Field) {
			Field field= (Field) element;
			return field.getName();
		}
		return element.toString();
	}
	
	/*
	 * @see org.eclipse.jface.viewers.LabelProvider#getImage(java.lang.Object)
	 */
	public Image getImage(Object element) {
		String imageName= ISharedImages.IMG_OBJ_ELEMENT;
		if (element instanceof Field) {
			Field field= (Field) element;
			try {
				imageName= (String) field.get(field);
			} catch (IllegalArgumentException e) {
				error(e, Messages.getString("LabelProvider.fieldError")); //$NON-NLS-1$
			} catch (IllegalAccessException e) {
				error(e, Messages.getString("LabelProvider.fieldError")); //$NON-NLS-1$
			}
		}
		return filter(PlatformUI.getWorkbench().getSharedImages().getImage(imageName));
	}
	
	/**
	 * Sets the list of image filters.
	 * 
	 * @param filters the list of filters
	 */
	public void setFilters(IImageFilter[] filters) {
		fImageFilters= Arrays.asList(filters);
	}

	/**
	 * Filters the given image. This method is leaking images. For the purpose
	 * of demonstration we let it as it is.
	 * 
	 * @param image the image to be filtered
	 * @return the filtered image or <code>null</code>
	 */
	private Image filter(Image image) {
		Iterator e= getImageFilters().iterator();
		while (e.hasNext()) {
			final IImageFilter filter= (IImageFilter) e.next();
			final Image inputImage= image;
			final Image[] outputImage= new Image[1];
			ISafeRunnable safeRunnable= new ISafeRunnable() {
				public void run() throws Exception {
					outputImage[0]= filter.filter(inputImage);
				}
				public void handleException(Throwable t) {
					error(t, Messages.getString("LabelProvider.error.filtering")); //$NON-NLS-1$
				}
			};
			
			Platform.run(safeRunnable);
			image= outputImage[0];
			if (image == null)
				return null;
		}
		return image;
	}

	/**
	 * Returns the list of image filters registered with this label provider.
	 * 
	 * @return the list of image filters
	 */
	private List getImageFilters() {
		if (fImageFilters == null)
			fImageFilters= loadImageFilters();
		return fImageFilters;
	}

	/**
	 * Loads and returns the registered image filters.
	 * 
	 * @return the loaded image filters
	 */
	private List loadImageFilters() {
		fImageFilters= new ArrayList();
		
		IExtensionPoint extensionPoint= Platform.getExtensionRegistry().getExtensionPoint(IconExplorerPlugin.getId(), "imageFilters"); //$NON-NLS-1$
		if (extensionPoint != null) {
			IConfigurationElement[] elements= extensionPoint.getConfigurationElements();
			if (elements != null) {
				for (int i= 0; i < elements.length; i++) {
					IImageFilter filter= null;
					try {
						filter= (IImageFilter) elements[i].createExecutableExtension("class"); //$NON-NLS-1$
					} catch (CoreException x) {
						error(x, Messages.getString("LabelProvider.error.creating")); //$NON-NLS-1$
					}
					if (filter != null)
						fImageFilters.add(filter);
				}
			}
		}
		
		return fImageFilters;
	}

	/**
	 * Handles the given throwable.
	 * 
	 * @param throwable the throwable
	 */
	private void error(Throwable throwable, String errorMessage) {
		Status s= new Status(IStatus.ERROR, IconExplorerPlugin.getId(), IStatus.ERROR, errorMessage, throwable);
		IconExplorerPlugin.getDefault().getLog().log(s);
	}
}
