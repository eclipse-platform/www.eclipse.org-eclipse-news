/*******************************************************************************
 * Copyright (c) 2000, 2003 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.iconexplorer.internal;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Display;

import org.eclipse.iconexplorer.IImageFilter;

/**
 * A filter for creating gray images.
 */
public class GrayFilter implements IImageFilter {

	/*
	 * @see org.eclipse.iconexplorer.IImageFilter#filter(org.eclipse.swt.graphics.Image)
	 */
	public Image filter(Image image) {
		if (image == null)
			return null;
		return new Image(Display.getDefault(), image, SWT.IMAGE_GRAY);
	}
}
