package org.eclipse.iconexplorer.internal;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IViewActionDelegate;

/**
 * Action delegate for the contributed view part tool bar action. This refresh
 * operation is only used for utilizing hot-code-replacement while refining the
 * <code>ContentProvider</code> and the <code>LabelProvider</code>.
 */
public class RefreshActionDelegate implements IViewActionDelegate {
	
	/** The view part this action delegate operates on. */
	private IconViewPart fIconViewPart;

	/**
	 * Creates a new delegate for the refresh action to appear in the view part tool bar.
	 */
	public RefreshActionDelegate() {
	}

	/*
	 * @see org.eclipse.ui.IActionDelegate#run(org.eclipse.jface.action.IAction)
	 */
	public void run(IAction action)  {
		if (fIconViewPart != null)
			fIconViewPart.refresh();
	}

	/*
	 * @see org.eclipse.ui.IActionDelegate#selectionChanged(org.eclipse.jface.action.IAction, org.eclipse.jface.viewers.ISelection)
	 */
	public void selectionChanged(IAction action, ISelection selection)  {
	}

	/*
	 * @see org.eclipse.ui.IViewActionDelegate#init(org.eclipse.ui.IViewPart)
	 */
	public void init(IViewPart view)  {
		if (view instanceof IconViewPart)
			fIconViewPart= (IconViewPart) view;
		
	}
}
