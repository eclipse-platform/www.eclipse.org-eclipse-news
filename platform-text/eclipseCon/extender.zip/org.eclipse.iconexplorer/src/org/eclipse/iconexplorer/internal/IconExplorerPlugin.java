package org.eclipse.iconexplorer.internal;

import org.eclipse.core.runtime.IPluginDescriptor;

import org.eclipse.ui.plugin.AbstractUIPlugin;

/**
 * The icon explorer plug-in class.
 */
public class IconExplorerPlugin extends AbstractUIPlugin {
	
	/** The shared instance. */
	private static IconExplorerPlugin fgPlugin;
	
	/**
	 * Creates a new icon explorer plug-in.
	 * 
	 * @param descriptor the plug-in descriptor
	 */
	public IconExplorerPlugin(IPluginDescriptor descriptor) {
		super(descriptor);
		fgPlugin = this;
	}

	/**
	 * Returns the shared instance.
	 * 
	 * @return the shared instance
	 */
	public static IconExplorerPlugin getDefault() {
		return fgPlugin;
	}
	
	/**
	 * Returns the id of the shared plug-in instance.
	 * 
	 * @return the id of the shared plug-in instance
	 */
	public static String getId() {
		return getDefault().getDescriptor().getUniqueIdentifier();
	}
}
