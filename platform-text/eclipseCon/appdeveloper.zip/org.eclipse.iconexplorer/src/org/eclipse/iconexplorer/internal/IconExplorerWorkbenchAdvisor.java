/*******************************************************************************
 * Copyright (c) 2000, 2003 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.iconexplorer.internal;

import org.eclipse.ui.application.IWorkbenchWindowConfigurer;
import org.eclipse.ui.application.WorkbenchAdvisor;

/**
 * The work bench advisor defining the appearance of the workbench window for
 * the icon explorer application.
 */
public class IconExplorerWorkbenchAdvisor extends WorkbenchAdvisor {

	/*
	 * @see org.eclipse.ui.application.WorkbenchAdvisor#getInitialWindowPerspectiveId()
	 */
	public String getInitialWindowPerspectiveId() {
		return "org.eclipse.iconexplorer.perspective"; //$NON-NLS-1$
	}
	
	/*
	 * @see org.eclipse.ui.application.WorkbenchAdvisor#preWindowOpen(org.eclipse.ui.application.IWorkbenchWindowConfigurer)
	 */
	public void preWindowOpen(IWorkbenchWindowConfigurer configurer) {
		configurer.setShowShortcutBar(false);
		configurer.setShowMenuBar(false);
		configurer.setShowProgressIndicator(false);
		configurer.setShowStatusLine(false);
		configurer.setShowCoolBar(false);
	}
	
	/*
	 * @see org.eclipse.ui.application.WorkbenchAdvisor#postWindowOpen(org.eclipse.ui.application.IWorkbenchWindowConfigurer)
	 */
	public void postWindowOpen(IWorkbenchWindowConfigurer configurer) {
		configurer.setTitle(Messages.getString("IconExplorerWorkbenchAdvisor.window.title")); //$NON-NLS-1$
	}
}
