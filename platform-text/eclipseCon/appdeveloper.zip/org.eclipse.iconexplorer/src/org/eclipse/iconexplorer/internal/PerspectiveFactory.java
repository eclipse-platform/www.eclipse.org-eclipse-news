package org.eclipse.iconexplorer.internal;

import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;

/**
 * The perspective factory defining the perspective for the icon explorer rich
 * client platform application. The layout consists of a single view only.
 */
public class PerspectiveFactory implements IPerspectiveFactory {
	
	/**
	 * Creates a new perspective factory.
	 */
	public PerspectiveFactory() {
	}

	/*
	 * @see org.eclipse.ui.IPerspectiveFactory#createInitialLayout(org.eclipse.ui.IPageLayout)
	 */
	public void createInitialLayout(IPageLayout layout) {
		String editorArea= layout.getEditorArea();
		layout.addView("org.eclipse.iconexplorer.iconview", IPageLayout.TOP, 1, editorArea); //$NON-NLS-1$
		layout.setEditorAreaVisible(false);
	}
}
