/*******************************************************************************
 * Copyright (c) 2004, 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.ui.examples.rcp.texteditor;

import org.eclipse.swt.graphics.Point;

import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.application.ActionBarAdvisor;
import org.eclipse.ui.application.IActionBarConfigurer;
import org.eclipse.ui.application.IWorkbenchWindowConfigurer;
import org.eclipse.ui.application.WorkbenchAdvisor;
import org.eclipse.ui.application.WorkbenchWindowAdvisor;
import org.eclipse.ui.examples.rcp.texteditor.actions.TextEditorActionBarAdvisor;


public class TextEditorWorkbenchAdvisor extends WorkbenchAdvisor {
	public TextEditorWorkbenchAdvisor() {
	}

    public String getInitialWindowPerspectiveId() {
		return "org.eclipse.ui.examples.rcp.texteditor.TextEditorPerspective"; //$NON-NLS-1$
	}
	
    public WorkbenchWindowAdvisor createWorkbenchWindowAdvisor(IWorkbenchWindowConfigurer configurer) {
		return new WorkbenchWindowAdvisor(configurer) {
            public void preWindowOpen() {
				super.preWindowOpen();
				IWorkbenchWindowConfigurer wc= getWindowConfigurer();
				wc.setInitialSize(new Point(600, 450));
				wc.setShowCoolBar(true);
				wc.setShowStatusLine(true);
			}

			/*
			 * @see org.eclipse.ui.application.WorkbenchWindowAdvisor#postWindowCreate()
			 * @since 3.3
			 */
			public void postWindowCreate() {
				super.postWindowCreate();
				IWorkbenchWindowConfigurer wc= getWindowConfigurer();
				IWorkbenchPage[] pages= wc.getWindow().getPages();
				for (int i=0; i < pages.length; i++) {
					pages[i].hideActionSet("org.eclipse.ui.actionSet.openFiles"); //$NON-NLS-1$
//					pages[i].hideActionSet("org.eclipse.ui.edit.text.actionSet.annotationNavigation");
//					pages[i].hideActionSet("org.eclipse.ui.edit.text.actionSet.navigation");
				}
				
			}
			
            /*
             * @see org.eclipse.ui.application.WorkbenchWindowAdvisor#createActionBarAdvisor(org.eclipse.ui.application.IActionBarConfigurer)
             */
            public ActionBarAdvisor createActionBarAdvisor(IActionBarConfigurer abConfigurer) {
				return new TextEditorActionBarAdvisor(abConfigurer);
			}
		};
	}
}
