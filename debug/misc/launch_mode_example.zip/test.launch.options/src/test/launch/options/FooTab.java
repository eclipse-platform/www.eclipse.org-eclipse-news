package test.launch.options;
import java.util.HashSet;
import java.util.Set;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.debug.core.ILaunchConfiguration;
import org.eclipse.debug.core.ILaunchConfigurationListener;
import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
import org.eclipse.debug.internal.ui.DebugUIPlugin;
import org.eclipse.debug.ui.AbstractLaunchConfigurationTab;
import org.eclipse.jdt.internal.debug.ui.SWTUtil;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;


/**
 *
 */
public class FooTab extends AbstractLaunchConfigurationTab implements ILaunchConfigurationListener {

	protected Button fButt = null;
	protected Set fOptions = null;

	/**
	 * @see org.eclipse.debug.ui.ILaunchConfigurationTab#createControl(org.eclipse.swt.widgets.Composite)
	 */
	public void createControl(Composite parent) {
		Composite comp = SWTUtil.createComposite(parent, parent.getFont(), 1, 1, GridData.FILL_BOTH);
		fButt = SWTUtil.createCheckButton(comp, "Check me to retarget the launch delegate.", false);
		fButt.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent e) {
			}

			public void widgetSelected(SelectionEvent e) {
				updateLaunchConfigurationDialog();
			}
			
		});
		setControl(comp);
		getLaunchManager().addLaunchConfigurationListener(this);
	}
	
	/**
	 * @see org.eclipse.debug.ui.ILaunchConfigurationTab#getName()
	 */
	public String getName() {
		return "Foo Tab";
	}

	/**
	 * @return the set of modes this tab works with
	 */
	protected Set getModes() {
		Set set = new HashSet();
		set.add("footab");
		return set;
	}
	
	/**
	 * @see org.eclipse.debug.ui.AbstractLaunchConfigurationTab#dispose()
	 */
	public void dispose() {
		getLaunchManager().removeLaunchConfigurationListener(this);
		super.dispose();
	}

	/**
	 * @see org.eclipse.debug.ui.ILaunchConfigurationTab#initializeFrom(org.eclipse.debug.core.ILaunchConfiguration)
	 */
	public void initializeFrom(ILaunchConfiguration configuration) {
		try {
			Set modes = configuration.getModes();
			if(modes != null) {
				modes.add(getLaunchConfigurationDialog().getMode());
				fButt.setSelection(getModes().containsAll(modes));
			}
			else {
				fButt.setSelection(false);
			}
		}
		catch(CoreException ce) {}
	}

	/**
	 * @see org.eclipse.debug.ui.ILaunchConfigurationTab#performApply(org.eclipse.debug.core.ILaunchConfigurationWorkingCopy)
	 */
	public void performApply(ILaunchConfigurationWorkingCopy configuration) {
		if(fButt.getSelection()) {
			configuration.addModes(getModes());
		}
		else {
			configuration.removeModes(getModes());
		}
	}

	/**
	 * @see org.eclipse.debug.ui.ILaunchConfigurationTab#setDefaults(org.eclipse.debug.core.ILaunchConfigurationWorkingCopy)
	 */
	public void setDefaults(ILaunchConfigurationWorkingCopy configuration) {}

	/**
	 * @see org.eclipse.debug.ui.AbstractLaunchConfigurationTab#getId()
	 */
	public String getId() {
		return "test.launch.options.footab";
	}

	/**
	 * @see org.eclipse.debug.core.ILaunchConfigurationListener#launchConfigurationChanged(org.eclipse.debug.core.ILaunchConfiguration)
	 */
	public void launchConfigurationChanged(ILaunchConfiguration configuration) {
		try {
			Set modes = configuration.getModes();
			modes.add(getLaunchConfigurationDialog().getMode());
			if(!fButt.isDisposed()) {
				boolean sel = fButt.getSelection();
				if(!sel & modes.containsAll(getModes())) {
					fButt.setSelection(true);
				}
				else if(sel & !modes.containsAll(getModes())) {
					fButt.setSelection(false);
				}	
			}
		}
		catch(CoreException ce) {DebugUIPlugin.log(ce);}
	}

	/**
	 * @param configuration
	 */
	public void launchConfigurationAdded(ILaunchConfiguration configuration) {}

	/**
	 * @param configuration
	 */
	public void launchConfigurationRemoved(ILaunchConfiguration configuration) {}
}
