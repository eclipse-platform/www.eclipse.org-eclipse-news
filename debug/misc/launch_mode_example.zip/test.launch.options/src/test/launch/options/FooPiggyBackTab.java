package test.launch.options;

import java.util.HashSet;
import java.util.Set;

public class FooPiggyBackTab extends FooTab {

	
	/**
	 * @see test.launch.options.FooTab#getName()
	 */
	public String getName() {
		return "Foo Piggyback Tab";
	}
	
	/**
	 * @see test.launch.options.FooTab#getId()
	 */
	public String getId() {
		return "test.launch.options.anttab";
	}
	
	/**
	 * @return the set of modes this tab works with
	 */
	public Set getModes() {
		if(fOptions == null) {
			fOptions = new HashSet();
			fOptions.add("ant");
			fOptions.add("test");
		}
		return fOptions;
	}
	
}
