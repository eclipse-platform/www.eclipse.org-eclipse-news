/*******************************************************************************
 * Copyright (c) 2000, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.debug.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.InputDialog;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.window.Window;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.texteditor.IDocumentProvider;
import org.eclipse.ui.texteditor.ITextEditor;

/**
 * Inserts a line into the build notes to indicate a bug has been verified.
 */
public class VerifyBugActionDelegate implements IWorkbenchWindowActionDelegate {
    
    private String fBugNumber;
    
    public VerifyBugActionDelegate() {
    }
    
    /* (non-Javadoc)
     * @see org.eclipse.ui.IWorkbenchWindowActionDelegate#dispose()
     */
    public void dispose() {
    }

    /* (non-Javadoc)
     * @see org.eclipse.ui.IWorkbenchWindowActionDelegate#init(org.eclipse.ui.IWorkbenchWindow)
     */
    public void init(IWorkbenchWindow window) {
    }

    /* (non-Javadoc)
     * @see org.eclipse.ui.IActionDelegate#run(org.eclipse.jface.action.IAction)
     */
    public void run(IAction action) {
        // get the bug number
        InputDialog dialog = new InputDialog(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(),
                "Verify Bug", "Enter bug number:", fBugNumber, null); //$NON-NLS-1$ //$NON-NLS-2$
        if (dialog.open() == Window.CANCEL) {
            return;
        }
        fBugNumber = dialog.getValue().trim();
        if (fBugNumber.length() == 0) {
            return;
        }
        
        // get the bug title
        URL url;
        try {
            url = new URL("https://bugs.eclipse.org/bugs/show_bug.cgi?id=" + fBugNumber); //$NON-NLS-1$
        } catch (MalformedURLException e) {
            e.printStackTrace();
            return;
        }
        URLConnection connection = null;
        String title = null;
        try {
            connection = url.openConnection();
            InputStream inputStream = connection.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            StringBuffer page = new StringBuffer();
            String line = reader.readLine();
            while (line != null) {
                page.append(line);
                line = reader.readLine();
            }
            reader.close();
            Pattern pattern = Pattern.compile("<title>.*</title>"); //$NON-NLS-1$
            Matcher matcher = pattern.matcher(page);
            if (matcher.find()) {
                int start = matcher.start() + "<title>".length(); //$NON-NLS-1$
                int end = matcher.end() - "</title>".length(); //$NON-NLS-1$
                title = page.substring(start, end);
                int index = title.indexOf("-"); //$NON-NLS-1$
                if (index >= 0) {
                    title = title.substring(index + 1);
                    title = title.trim();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }
        
        // make the new text to insert
        StringBuffer text = new StringBuffer();
        text.append("<a href=\"http://bugs.eclipse.org/bugs/show_bug.cgi?id="); //$NON-NLS-1$
        text.append(fBugNumber);
        text.append("\">"); //$NON-NLS-1$
        text.append(fBugNumber);
        text.append("</a>: "); //$NON-NLS-1$
        text.append(title);
        text.append("<br>"); //$NON-NLS-1$
        
        // insert into editor
        IEditorPart editor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor();
        if (editor instanceof ITextEditor) {
            try {
	            ITextEditor textEditor = (ITextEditor)editor;
	            IDocumentProvider documentProvider = textEditor.getDocumentProvider();
	            documentProvider.connect(this);
	            IDocument document = documentProvider.getDocument(editor.getEditorInput());
	            ITextSelection textSelection = (ITextSelection) textEditor.getSelectionProvider().getSelection();
	            document.replace(textSelection.getOffset(), textSelection.getLength(), text.toString());
	            documentProvider.disconnect(this);
            } catch (CoreException e) {
                e.printStackTrace();
            } catch (BadLocationException e) {
                e.printStackTrace();
            }
        }
    }

    /* (non-Javadoc)
     * @see org.eclipse.ui.IActionDelegate#selectionChanged(org.eclipse.jface.action.IAction, org.eclipse.jface.viewers.ISelection)
     */
    public void selectionChanged(IAction action, ISelection selection) {        
    }
}
