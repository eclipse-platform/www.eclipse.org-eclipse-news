package threadgroups;
import java.security.SecureRandom;
import java.util.concurrent.Executor;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class TaskUtil {

	private final ThreadGroup threadGroup;

	private SecureRandom random;

	public TaskUtil() {
		threadGroup = new ThreadGroup("Tasks");
		random = new SecureRandom();
	}

	private Executor[] pools;

	public void createPools(int i) {
		if (i == 0) {
			i++;
		}
		pools = new Executor[i];
		for (int j = 0; j < i; j++) {
			pools[j] = new ThreadPoolExecutor(10, 10, 0L,
					TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>(
							1000), new MyThreadFactory("Group-" + j,
							threadGroup));
		}
	}

	static class MyThreadFactory implements ThreadFactory {
		final ThreadGroup parentGroup;

		final AtomicInteger threadNumber = new AtomicInteger(1);

		final String namePrefix;

		MyThreadFactory(String prefix, ThreadGroup parentGroup) {
			this.parentGroup = new ThreadGroup(parentGroup, prefix);
			namePrefix = prefix + "-thread-";
		}

		public Thread newThread(Runnable r) {
			Thread t = new Thread(parentGroup, r, namePrefix
					+ threadNumber.getAndIncrement(), 0);
			if (t.isDaemon())
				t.setDaemon(false);
			if (t.getPriority() != Thread.NORM_PRIORITY)
				t.setPriority(Thread.NORM_PRIORITY);
			return t;
		}
	}

	public void doWork(Runnable task) {
		pools[Math.abs(random.nextInt()) % pools.length].execute(task);

	}

}
