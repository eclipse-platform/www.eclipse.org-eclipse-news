package threadgroups;
import java.security.SecureRandom;

/**
 * Creates a number of threads in named groups, continues to create and remove threads
 * as the program runs.
 * 
 * Code available on Eclipse Bug 169542
 * https://bugs.eclipse.org/bugs/show_bug.cgi?id=169542
 *
 */
public class Main {

	protected static Main singleton = new Main();

	public final ThreadGroup mainThreadGroup;

	private SchedulingUtil schedulingUtil;

	TaskUtil taskUtil;

	public static void main(String[] args) {
		getInstance().initialize();
		getInstance().go();
	}

	private void go() {
		taskUtil.createPools(new SecureRandom().nextInt(5));
		schedulingUtil.spawnJobs(new SecureRandom().nextInt(10));
	}

	public static Main getInstance() {
		return singleton;
	}

	private void initialize() {
		schedulingUtil = new SchedulingUtil();
		taskUtil = new TaskUtil();
	}

	public Main() {
		mainThreadGroup = new ThreadGroup("my-group");
	}

}
