package threadgroups;
import java.security.SecureRandom;

public class Job implements Runnable {

	private volatile String name;

	public Job(String name) {
		this.name = name;
		this.random = new SecureRandom();
	}

	private SecureRandom random;

	public void run() {
		if (random.nextBoolean()) {
			new Thread(name + "-util-thread") {

				public void run() {
					try {
						while (true) {
							System.out
									.println(this.getName()
											+ ": I'm a random utility thread - not from an executor");
							Thread.sleep(random.nextInt(10000));
						}
					} catch (InterruptedException e) {
					}
				}
			}.start();
		}

		for (int i = 0; i < random.nextInt(10); i++) {
			Main.getInstance().taskUtil.doWork(new ForeverTask());
		}

	}

}
