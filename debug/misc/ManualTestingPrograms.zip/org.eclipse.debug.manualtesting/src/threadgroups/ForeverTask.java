package threadgroups;
import java.security.SecureRandom;

public class ForeverTask implements Runnable {

	SecureRandom random = new SecureRandom();

	public void run() {
		try {
			while (true) {
				System.out.println(Thread.currentThread().getName()
						+ ": I'm a forever task");
				Thread.sleep(random.nextInt(5000));
			}
		} catch (InterruptedException e) {
		}
	}

}
