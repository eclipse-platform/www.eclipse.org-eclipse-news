package threadgroups;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class SchedulingUtil {

	private ThreadPoolExecutor executor;

	private final ThreadGroup schedulerThreadGroup;

	public SchedulingUtil() {
		schedulerThreadGroup = new ThreadGroup(
				Main.getInstance().mainThreadGroup, "scheduling");
		executor = new ThreadPoolExecutor(0, Integer.MAX_VALUE, 60L,
				TimeUnit.SECONDS, new SynchronousQueue<Runnable>(),
				new SchedulerThreadFactory(schedulerThreadGroup));
		
		new Thread(schedulerThreadGroup,"eclipse-hack"){

			public void run() {
					try {
						Thread.sleep(10000);
					} catch (InterruptedException e) {
					}
			}}.start();

	}

	public void spawnJobs(int i) {
		if (i == 0 ) {
			i++;
		}
		for (int j = 0; j < i; j++) {
			executor.execute(new Job("Job_" + j));
		}
	}

	static class SchedulerThreadFactory implements ThreadFactory {
		final AtomicInteger threadNumber = new AtomicInteger(1);

		final String namePrefix;

		private AtomicInteger groupNumber = new AtomicInteger(1);

		private ThreadGroup parentGroup;

		SchedulerThreadFactory(ThreadGroup schedulerThreadGroup) {
			namePrefix = "scheduler";
			parentGroup = schedulerThreadGroup;
		}

		public Thread newThread(Runnable r) {

			ThreadGroup threadGroup = new ThreadGroup(parentGroup, namePrefix
					+ "-group-" + groupNumber.getAndIncrement());
			Thread t = new Thread(threadGroup, r, namePrefix + "-thread-"
					+ threadNumber.getAndIncrement(), 0);
			if (t.isDaemon())
				t.setDaemon(false);
			if (t.getPriority() != Thread.NORM_PRIORITY)
				t.setPriority(Thread.NORM_PRIORITY);
			return t;
		}
	}

}
