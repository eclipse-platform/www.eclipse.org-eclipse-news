/*******************************************************************************
 * Copyright (c) 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package launchables;

/**
 * Contains a main method, an inner class with a main, a static method and non-static void method.
 */
public class MultiplePossibleMains {

	static class InnerClass{
		
		public static void main(String [] args){
			System.out.println("3");
		}
		
	}
	
	public void method(){
		
		System.out.println("1");
	}
	
	public static void main(String [] args){
		System.out.println("4");
	}
	
	public static void staticMethod(){
		System.out.println("2");
		
	}
	
}
