/*******************************************************************************
 * Copyright (c) 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package java6;

import java.util.ArrayList;

/**
 * Class to test the all references feature
 * 
 * @since 3.4
 */
public class AllInstancesTests {

	/**
	 * An object that can be referenced
	 */
	class RefObject {
		private int fNum = -1;
		
		public RefObject(int number) {
			fNum = number;
		}
		public String toString() {
			return "RefObject"+fNum;
		}
	}
	
	/**
	 * A class that can be referenced
	 */
	class RefClass {
		public ArrayList<RefObject> makeReferences(int number) {
			ArrayList<RefObject> list = new ArrayList<RefObject>(number);
			for(int i = 0; i < number; i++) {
				list.add(new RefObject(i));
			}
			return list;
		}
	}
	
	/**
	 * Creates the specified number of references of <code>RefObject</code>, and returns them as an array list
	 * @param number
	 * @return
	 */
	public ArrayList<RefObject> makeRefObjectReferences(int number) {
		ArrayList<RefObject> list = new ArrayList<RefObject>(number);
		for(int i = 0; i < number; i++) {
			list.add(new RefObject(i));
		}
		return list;
	}
	
	/**
	 * Creates the specified number of references of <code>RefClass</code>, and returns them as an array list
	 * @param number
	 * @return
	 */
	public ArrayList<RefClass> makeRefClassReferences(int number) {
		ArrayList<RefClass> list = new ArrayList<RefClass>(number);
		for(int i = 0; i < number; i++) {
			list.add(new RefClass());
		}
		return list;
	}
	
	/**
	 * main test runner
	 * @param args
	 */
	public static void main(String[] args) {
		AllInstancesTests ait = new AllInstancesTests();
		ArrayList<?> list = ait.makeRefObjectReferences(12);
		//check all instances of the following variable, should be 13
		RefObject ro = ait.new RefObject(-1);
		list = ait.makeRefClassReferences(1001); //TODO breakpoint
		//check all instances of the following variable, should be 1002
		RefClass rc = ait.new RefClass();
		System.out.println("end");  //TODO breakpoint
	}
}
