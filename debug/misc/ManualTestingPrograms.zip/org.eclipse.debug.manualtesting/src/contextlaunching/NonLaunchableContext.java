/*******************************************************************************
 * Copyright (c) 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package contextlaunching;

/**
 * Class that cannot be context launched
 * 
 * Try launching this file with the launch settings set to:
 * 
 * 1. always launch last
 * 2. launch last when not launchable
 * 3. launch project when not launchable
 */
public class NonLaunchableContext {

}
