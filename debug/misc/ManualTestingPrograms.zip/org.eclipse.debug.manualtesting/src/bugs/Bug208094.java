/*******************************************************************************
 * Copyright (c) 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package bugs;

import java.util.HashMap;
import java.util.Map;

/**
 * A bug appeared that raw types were shown for Map and logical structures only worked for
 * 
 * @since
 */
public class Bug208094 {

	private static String[] manyStrings = new String[500];
		
	public void testMap() {
		manyStrings = new String[500];
		manyStrings[25]="la";
        Map map = new HashMap();
        for (int i = 0; i < 100; i ++) {
                map.put(Integer.toHexString(i), Integer.toBinaryString(i));
        }
        System.out.println(map);
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		manyStrings[10] = "foo";
		Bug208094 bug = new Bug208094();
		bug.testMap();
	}

}
