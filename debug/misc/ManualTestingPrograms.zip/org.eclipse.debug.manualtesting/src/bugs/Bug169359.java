package bugs;
import java.util.ArrayList;
import java.util.List;

import simple.ALotOfConstants;
import simple.ALotOfStaticVars;

/**
 * Tests the ability of the Variables view (and derivatives) to filter out
 * statics and fields.
 *
 * See https://bugs.eclipse.org/bugs/show_bug.cgi?id=169359
 *
 */
public class Bug169359 implements ALotOfConstants
{
	private static Object[] manyStrings = new Object[500];
	
    public static final class TestInner extends ALotOfStaticVars implements ALotOfConstants
    {
    	public Object[] manyStrings = new Object[500];
        public String a = "a";
        public String b = "b";
        public String c = "c";
        public int x = 1;
        public int y = 2;
        public int z = 3;
    }
    
    public static void main (String[] args)
    {
    	manyStrings[10] = "foo";
        List lst = new ArrayList();
        lst.add(new TestInner());
        lst.add(new TestInner());
        TestInner foobar = new TestInner();
        foobar.manyStrings[50]="la";
        return;  // Breakpoint here
    }
}