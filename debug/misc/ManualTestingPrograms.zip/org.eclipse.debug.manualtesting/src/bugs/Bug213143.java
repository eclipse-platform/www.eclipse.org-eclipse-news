package bugs;

public class Bug213143 {
	public static void main(String[] args) {
		System.out.println((char)156);
		System.out.println((char)163);
	}
}
