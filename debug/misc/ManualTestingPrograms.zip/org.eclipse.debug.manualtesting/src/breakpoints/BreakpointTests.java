/*******************************************************************************
 * Copyright (c) 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package breakpoints;

/**
 * 
 * @since
 */
public class BreakpointTests {

	//class load bp
	enum E {};
	
	//class load 
	enum E1 {FOO, 
		TEST, 
		BAR
		};
	
	//watchpoints must work
	int field = -1;
	Object field2 = new Object();
	Object field3 = new Runnable() {
		public void run() {
		}
	};
	
	//line bp must appear, watchpoints not supported for final or static final fields
	final int field4 = 0; 
	static final Object field5 = new Object(); 
		
	/**
	 * Constructor
	 */
	//method bp must work
	public BreakpointTests() {
	}

	//method bp
	public void foo() {
		//line bp
		System.out.println("foo");
	}
	
	/**
	 * @param args
	 */
	//method bp must work
	public static void main(String[] args) {

	}

}

//class load must work
class OuterBreakpointsTests {
	
	//class load bp
	enum E {};
	
	//class load 
	enum E1 {FOO, 
		TEST, 
		BAR
		};
	
	//watchpoints must work
	int field = -1;
	Object field2 = new Object();
	Object field3 = new Runnable() {
		public void run() {
		}
	};
	
	//line bp must appear, watchpoints not supported for final or static final fields
	final int field4 = 0; 
	static final Object field5 = new Object(); 
	
	//class load must work
	static class InnerOBT {
		//class load bp
		enum E {};
		
		//class load 
		enum E1 {FOO, 
			TEST, 
			BAR
			};
		
		//watchpoints must work
		int field = -1;
		Object field2 = new Object();
		Object field3 = new Runnable() {
			public void run() {
			}
		};
		
		//line bp must appear, watchpoints not supported for final or static final fields
		final int field4 = 0; 
		static final Object field5 = new Object(); 
		
		//method bp
		public void foo() {
			//line bp
			System.out.println("foo");
		}
	}
	
	//class load must work
	class InnerOBT2 {
		
		//watchpoints must work
		int field = -1;
		Object field2 = new Object();
		Object field3 = new Runnable() {
			public void run() {
			}
		};
		
		//line bp must appear, watchpoints not supported for final or static final fields
		final int field4 = 0; 
		
		//method bp
		public void foo() {
			//line bp
			System.out.println("foo");
		}
	}
	
}