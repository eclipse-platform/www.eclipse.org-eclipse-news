/*******************************************************************************
 * Copyright (c) 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package breakpoints;

/**
 * 
 * @since
 */
//cannot set class load bps on an interface
public interface IBreakpointTests {
	
	//cannot set class load on inner interfaces
	interface InnerIBreakpointTests {
		
		//cannot set on fields of inner interfaces
		public int number2 = -1;
		
		//cannot set on methods in inner interfaces
		public void doSomething2();
		
	}
	
	//cannot set watchpoint or line bps on fields 
	public int number = -1;

	//cannot set bps on methods 
	public void doSomething();
	
}
