/*******************************************************************************
 * Copyright (c) 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package breakpoints;

/**
 * This class should be renamed once the breakpoints are created to ensure that
 * renaming maintains the breakpoints
 * 
 * The breakpoints for this file are available in the project in the Settings folder
 * @since
 */
//TODO class load bp on here
public class BreakpointRename {

	//TODO class load bp on here
	class Inner {
		
		//TODO watchpoints on these
		private int number = 0;
		private Object o = new Runnable() {
			public void run() {
			}
		};
		
		//TODO method bp here
		public void doSomething() {
			number = 1;
			System.out.println(number);
			//TODO line bp here
			o = null;
			System.out.println(o);
		}
	}
	
	//TODO class load here 
	static class StaticInner {
		
		//TODO class load here
		enum E {
			TEST, 
			TEST1, 
			TEST2
		};
		
		//TODO watchpoints on these
		private int number = 0;
		private Object o = new Runnable() {
			public void run() {
			}
		};
		
		//TODO method bp here
		public void doSomething() {
			number = 1;
			System.out.println(number);
			//TODO line bp here
			o = null;
			System.out.println(o);
		}
	}
	
	//TODO watchpoints on these
	private int number = 0;
	private Object o = new Runnable() {
		public void run() {
		}
	};

	//TODO class load here
	enum E {
		TEST, 
		TEST1, 
		TEST2
	};
	
	//TODO method bp here
	public void doSomething() {
		number = 1;
		System.out.println(number);
		//TODO line bp here
		o = null;
		System.out.println(o);
	}
	
	/**
	 * @param args
	 */
	//TODO method bp here
	public static void main(String[] args) {
	
	}

}

//TODO class load here
class Outer {
	//TODO class load here
	enum E {
		TEST, 
		TEST1, 
		TEST2
	};
	
	//TODO watchpoints on these
	private int number = 0;
	private Object o = new Runnable() {
		public void run() {
		}
	};
	
	//TODO method bp here
	public void doSomething() {
		number = 1;
		System.out.println(number);
		//TODO line bp here
		o = null;
		System.out.println(o);
	}
}

class Test {
	class InnerTest {
		
	}
}
