/*******************************************************************************
 * Copyright (c) 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package varview;

/**
 * Used by LogicalStructsAndDetailFormatters.java to test creation and
 * configuration of detail formatters.  Detail formatters are available
 * by importing TestingPreferences.epf in the Settings folder.
 * TODO Currently no way to export just detail formatters as preferences.
 */
public class HasDetailFormatters {
	
	private Object object;
	
	public HasDetailFormatters(Object object){
		this.object = object;
	}
	
	public String toString() {
		return "HasDetailFormatters Instance: " + object.toString();
	}
	
}
