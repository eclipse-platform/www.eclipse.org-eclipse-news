/*******************************************************************************
 * Copyright (c) 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package varview;
import java.util.Random;

/**
 * Creates instances of objects that will have logical structures and
 * detail formatters associated with them if the preference files were
 * imported.
 */
public class LogicalStructsAndDetailFormatters {

	public static void main (String[] args){
		
		System.out.println("Starting");
		
		Random anObject = new Random();
		Object[] anArray = new Object[5];
		anArray[0] = new Object();
		anArray[1] = "Hi there";
		anArray[2] = null;
		anArray[3] = anObject;
		anArray[4] = new LogicalStructsAndDetailFormatters();
		
		HasLogicalStructures logicA = new HasLogicalStructures(anObject,anArray);
		HasLogicalStructures logicB = new HasLogicalStructures(null,null);
		
		HasDetailFormatters detA = new HasDetailFormatters(anObject);
		HasDetailFormatters detB = new HasDetailFormatters(null);	
		
		// Breakpoint here
		System.out.println("Done.");
	}
}
