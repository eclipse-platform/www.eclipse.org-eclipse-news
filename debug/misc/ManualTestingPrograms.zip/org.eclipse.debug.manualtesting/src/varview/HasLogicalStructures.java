/*******************************************************************************
 * Copyright (c) 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package varview;

/**
 * Used by LogicalStructsAndDetailFormatters.java to test 
 * creation/configuration of logical structures. Import the 
 * logical structures from LogicalStructures.epf in the
 * Settings folder to have objects of this type have multiple 
 * choices for logical structures.
 *
 */
public class HasLogicalStructures {

	private Object object;
	private Object[] array;
	
	public HasLogicalStructures(Object object, Object[] array){
		this.object = object;
		this.array = array;
	}
	
	public String toString() {
		return "HasLogicalStructures Instance: " + object.toString() + " | " + array.toString();
	}
	
}
