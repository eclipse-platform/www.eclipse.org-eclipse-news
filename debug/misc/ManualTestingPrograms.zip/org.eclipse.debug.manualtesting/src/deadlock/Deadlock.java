package deadlock;

/**
 * Creates a deadlock.
 */
public class Deadlock {
	
	class Worker implements Runnable {
		
		private Object fGet;
		private Object fWait;
		private String fName;
		
		public Worker(String name, Object get, Object wait) {
			fName = name;
			fGet = get;
			fWait = wait;
		}
		public void run() {
			// obtain lock 1 and wait for lock 2
			synchronized (fGet) {
				System.out.println(fName + " obtained lock: " + fGet);
				// first wait a second so thread 2 can get the second lock
				try {
					Thread.sleep(1000);
					System.out.println(fName + " waiting for lock: " + fWait);
					synchronized (fWait) {
						System.out.println(fName + " obtained lock: " + fWait);
					}
				} catch (InterruptedException e) {
				}
			}
		}
	}; 
	
	public static void main(String[] args) {
		new Deadlock().lock();
	}

	public void lock() {
		Object lock1 = "LOCK1";
		Object lock2 = "LOCK2";
		Worker worker1 = new Worker("Worker1", lock1, lock2);
		Worker worker2 = new Worker("Worker2", lock2, lock1);
		new Thread(worker1).start();
		new Thread(worker2).start();
	}
}
