/*******************************************************************************
 * Copyright (c) 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package java5;

import static java.lang.Math.PI;
import static java.lang.Math.cos;
import static java.lang.Math.max;
import static java.lang.Math.random;
import static java.lang.System.currentTimeMillis;
import static java.lang.System.out;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

/**
 * Uses simple cases to test the various Java 5 features.  Helpful for testing
 * evaluations.  For testing generics, use the Generics class in the same package.
 * TODO Add more complex cases, possibly to a new class
 * @see Generics
 * @since 3.4
 */
public class Java5Evaluations {
	
	private enum enumerationsRock { ONE, TWO, THREE, FIVE_BILLION };

	public static void main(String[] args) {
		Java5Evaluations instance = new Java5Evaluations();
		List fooList = new ArrayList();
		fooList.add("hi");
		fooList.add("one");
		instance.forLoop(fooList);
		instance.forLoop2(new int[]{1,2,5,9});
		instance.autoboxing(new int[]{11,22,33,44,55});
		instance.printEnumeration();
		instance.haveFunWithStaticImports();
		instance.manyArguments("Weeeeee!", "this", "can", "have", "as", "many", "arguments", "as", "I", "want", null, null, new Random());
		instance.readInput();
		instance.usingPrintF("la", 2, 3.14);
		System.out.println("Done");

	}

	public String forLoop(Collection<String> c) {
		StringBuffer buffer = new StringBuffer();
		for(String str : c) {
			buffer.append(str);
		}
		System.out.println(buffer);
		return buffer.toString();
	}

	public int forLoop2(int[] array) {
		int sum = 0;
		for(int i : array) {
			sum += i;
		}
		System.out.println(sum);
		return sum;
	}
	
	public List autoboxing(int[] array){
		List<Integer> list = new ArrayList();
		for(int i: array){
			list.add(i);
		}
		list.add(1);
		list.add(Integer.MAX_VALUE);
		list.add(Integer.MIN_VALUE);
		return list;
	}
	
	public void printEnumeration(){
		for(enumerationsRock stuff : enumerationsRock.values()) {
			switch(stuff) {
			case ONE:
				System.out.println("1");
				break;
			case TWO:
				System.out.println("2");
				break;
			case THREE:
				System.out.println("3");
				break;
			case FIVE_BILLION:
				System.out.println("too many");
				break;
			}
		}
	}
	
	public void haveFunWithStaticImports(){
		out.println(cos(123.456));
		out.println(max(PI, random()));
		out.println(currentTimeMillis());
	}
	
	public void manyArguments(String aString, Object ... objects){
		for (Object current : objects){
			out.print(current + " ");
		}
		System.out.println(aString + ": " + objects.length);
	}
	
	public void readInput(){
		Scanner reader = new Scanner(System.in);
		System.out.println("An integer");
		int i = reader.nextInt();
		System.out.println("A double:");
		double d = reader.nextDouble();
		System.out.println("A string");
		String foo = reader.next();
		System.out.println(i + " " + d + " " + foo);
	}
	
	public void usingPrintF(String oneString, int twoInt, double threeDouble){
		System.out.printf("String %s Integer %d Double %e",oneString, twoInt, threeDouble);
	}
	
}
