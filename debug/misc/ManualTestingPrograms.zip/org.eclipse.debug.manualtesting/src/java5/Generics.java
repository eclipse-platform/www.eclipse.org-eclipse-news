/*******************************************************************************
 * Copyright (c) 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package java5;

import java.util.Collection;
import java.util.List;

/**
 * This test is, for the moment, a copy of the ForceReturnTests in the java6 package.
 * This class provides a variety of uses of generics to test java5 evaluations. 
 * 
 * @since 3.4
 */
public class Generics {

	/**
	 * Dummy class to be incompatible with all of the other tests
	 */
	class IncompatibleType {}
	
	/**
	 * Class to test nested parameterized types
	 * @param <B>
	 */
	class A<B extends List<Integer>> {
		private String fString;
		
		public A(String text) {
			fString = text;
		}
		
		public String toString() {
			return fString;
		}
	}
	
	/**
	 * Class to test nested parameterized types with a '?'
	 * @param <F>
	 */
	class E<F extends List<?>> {
		private String fString;
		
		public E(String text) {
			fString = text;
		}
		
		public String toString() {
			return fString;
		}
	}
	
	/**
	 * tests this crazy class
	 * @param <T>
	 */
	class G<T extends List<E<List<? extends Collection<E<List<? extends String>>>>>>> {
		private String fString;
		
		public G(String text) {
			fString = text;
		}
		
		public String toString() {
			return fString;
		}
	}
	
	/**
	 * Class to test simple parameterized types
	 * @param <A>
	 */
	class C<A> {
		private String fString;
		
		public C(String text) {
			fString = text;
		}
		
		public String toString() {
			return fString;
		}
	}
	
	/**
	 * Inner class for testing
	 */
	class D {
		private String fString;
		
		public D(String text) {
			fString = text;
		}
		
		public String toString() {
			return fString;
		}
	}
	
	/**
	 * tests getting an <code>int</code> value
	 * @return
	 */
	public int getIntValue() {
		int i = 100;
		return i;  //TODO breakpoint
	}
	
	/**
	 * tests getting a <code>double</code> value
	 * @return
	 */
	public double getDoubleValue() {
		double d = 100.100;
		return d; //TODO breakpoint
	}
	
	/**
	 * tests getting a <code>short</code> value
	 * @return
	 */
	public short getShortValue() {
		short s = 100;
		return s; //TODO breakpoint
	}
	
	/**
	 * tests getting a <code>float</code> value
	 * @return
	 */
	public float getFloatValue() {
		float f = 100.100f;
		return f; //TODO breakpoint
	}
	
	/**
	 * tests getting an <code>Object</code> value
	 * @return
	 */
	public Object getObjectValue() {
		Object o = new Object();
		return o; //TODO breakpoint
	}
	
	/**
	 * tests getting an <code>Integer</code> value
	 * @return
	 */
	public Integer getIntObjectValue() {
		Integer i = new Integer(100);
		return i; //TODO breakpoint
	}
	
	/**
	 * tests getting a <code>Short</code> value
	 * @return
	 */
	public Short getShortObjectValue() {
		Short s = new Short((short)100);
		return s; //TODO breakpoint
	}
	
	/**
	 * tests getting a <code>Double</code> value
	 * @return
	 */
	public Double getDoubleObjectValue() {
		Double d = new Double(100.100);
		return d; //TODO breakpoint
	}
	
	/**
	 * tests getting a <code>Float</code> value
	 * @return
	 */
	public Float getFloatObjectValue() {
		Float f = new Float(100.100);
		return f; //TODO breakpoint
	}
	
	/**
	 * tests getting a <code>String</code> value
	 * @return
	 */
	public String getStringValue() {
		String s = new String("Test");
		return s; //TODO breakpoint
	}
	
	/**
	 * tests getting a <code>D</code> value
	 * @return
	 */
	public D getObjectValue1() {
		D d = new D("orginal");
		return d; //TODO breakpoint
	}
	
	/**
	 * tests getting a <code>C</code> value
	 * @return
	 */
	public C<A<List<Integer>>> getObjectValue2() {
		C<A<List<Integer>>> c = new C<A<List<Integer>>>("original");
		return c; //TODO breakpoint
	}
	
	/**
	 * tests getting an <code>A</code> object
	 * @return
	 */
	public A<List<Integer>> getObjectValue3() {
		A<List<Integer>> a = new A<List<Integer>>("original");
		return a; //TODO breakpoint
	}
	
	/**
	 * tests getting an <code>E</code> value
	 * @return
	 */
	public E<List<?>> getObjectValue4() {
		E<List<?>> e = new E<List<?>>("original");
		return e; //TODO breakpoint
	}
	
	/**
	 * tests getting a <code>G</code> value
	 * @return
	 */
	public G<List<E<List<? extends Collection<E<List<? extends String>>>>>>> getObjectValue5() {
		G<List<E<List<? extends Collection<E<List<? extends String>>>>>>> g = new G<List<E<List<? extends Collection<E<List<? extends String>>>>>>>("original");
		return g; //TODO breakpoint
	}
	
	/**
	 * Main runner for the class
	 * @param args
	 */
	public static void main(String[] args) {
		Generics frt = new Generics();
		//test using the IncompatibleType class to make sure that it fails for each of the methods
		// IncompatibleType ict = new IncompatibleType();
		int i = frt.getIntValue();
		double d = frt.getDoubleValue();
		float f =frt.getFloatValue();
		short s = frt.getShortValue();
		Integer in = frt.getIntObjectValue();
		frt.getDoubleObjectValue();
		Float fl = frt.getFloatObjectValue();
		Short sh = frt.getShortObjectValue();
		Object ob = frt.getObjectValue();
		D ov1 = frt.getObjectValue1();
		C<A<List<Integer>>> ov2 = frt.getObjectValue2();
		A<List<Integer>> ov3 = frt.getObjectValue3();
		E<List<?>> ov4 = frt.getObjectValue4();
		G<List<E<List<? extends Collection<E<List<? extends String>>>>>>> ov5 = frt.getObjectValue5();
	}
}
