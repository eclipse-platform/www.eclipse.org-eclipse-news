/*******************************************************************************
 * Copyright (c) 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package simple;

/**
 * Calls a method recursively as many times as a counter is set to or infinitely if set to -1
 *
 */
public class RecurseForever {
		
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		// Change the int to recurse that many times, use a negative number to recurse forever
		System.out.println(recurse(-1, true));
		
	}
	
	private static int recurse(int val, boolean done){
		if (val != 0){
			System.out.println(val);
			return recurse(val - 1, true);
		}
		return 0;
	}


}
