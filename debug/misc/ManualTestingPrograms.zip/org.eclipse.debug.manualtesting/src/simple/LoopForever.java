/*******************************************************************************
 * Copyright (c) 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package simple;

/**
 * Loops as many time as a integer is set to, or infinitely if set to a negative number.
 */
public class LoopForever {
	public static void main(String[] args) {
		// If positive, this will loop that many times, if negative, will loop forever 
		int count = -1;
		while (count != 0) {
			System.out.println(count);
			count--;
		}
	}
}
