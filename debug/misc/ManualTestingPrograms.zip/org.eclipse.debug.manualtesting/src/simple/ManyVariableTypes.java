package simple;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Vector;

/**
 * Contains a large variety of variables that can be inspected/evaluated/etc.
 * Feel free to add more (currently this class compiles under 1.4).
 *
 */
public class ManyVariableTypes {

	static String fStatic = "static";
	private String fPrivate = "private";
	private static final int TEN = 10;
	Integer fInt = new Integer(15);
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		StringBuffer buf = new StringBuffer();
		for(int i=0; i<30000; i++){
			buf.append('a');
		}
		
		String superLongString = buf.toString();
		
		long aLong = 123456789;
		
		Long anotherLong = new Long(aLong);
		
		System.out.println("Start Array!");
		
		Object[] theArray = new Object[3];
		theArray[0] = new Random(10);
		theArray[1] = new Random(11);
		theArray[2] = new Random(12);
		
		theArray[2] = null;
		theArray[1] = null;
		
		theArray = null;
		
		System.out.println("Done Array!");
		
		
		System.out.println("Start Vector!");
		
		Vector theVector = new Vector();
		theVector.add(new Random(10));
		theVector.add(new Random(11));
		theVector.add(new Random(12));
		
		theVector.remove(2);
		theVector.remove(1);
		
		theVector.removeAllElements();
		theVector = null;
				
		System.out.println("Done Vector!");
		
		System.out.println("Start Map!");
		
		Map theMap = new HashMap();
		theMap.put("0",new Random(10));
		theMap.put("1",new Random(11));
		theMap.put("2",new Random(12));
		
		theMap.remove("2");
		theMap.remove("1");
		
		theMap.clear();
		theMap = null;
		
		System.out.println("Done Map!");
		
		
		
		String[] stringArrayVar = new String[50];
		for (int j = 0; j < stringArrayVar.length; j++) {
			stringArrayVar[j] = "-" + j + "-";
		}
		
		
		Object[] objectArrayVar = new Object[200];
		for (int i=0; i<objectArrayVar.length; i++){
			objectArrayVar[i] = new Random();
		}
		
		int intVar = 2;
		String stringVar = "Everything";
		boolean booleanVar = true;
		
		Random random = new Random();
		switch (random.nextInt(2)){
		case 0:
			System.out.println("Case 0");
			break;
		case 1:
			System.out.println("Case 1");
			break;
		default:
			System.out.println("Default");
			break;
		}
		
		stringVar = "Changed!";
		List collection = new LinkedList();
		long currentTime = System.currentTimeMillis();
		while (stringVar.equals("Changed!")){
			collection.add("Hi " + (578 + 123 - 345 / 12 * 3 % 125));
			if (System.currentTimeMillis() > currentTime + 1000){
				stringVar = "Done!";
			}
		}
		
		System.out.println(stringVar);
		stringVar = "Whoa";
		stringVar = "TestMe";
		List list = new LinkedList();
		Map map = new HashMap();
		System.err.println("Oh crap");
		
	}

}
