import junit.framework.TestCase;


/**
 * The idea is to create a Java and JUnit launch config by running
 * this class and then rename the class and ensure the configurations 
 * are renamed as well
 * 
 * @since
 */
public class RefactoringConfigTestRename extends TestCase {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

	}

	public void testOne() {
		assertTrue(true);
	}
	
}
