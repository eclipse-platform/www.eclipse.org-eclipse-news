package stress;

import java.util.Random;

/**
 * Testcase to stress test the debug view
 * 1.  Set breakpoint to stop at thread 122
 * 2.  When stopped, hold down the F6 key to step
 * 
 * Ensure that the expansion and selection are maintained properly.
 * User should be able to continue stepping without clicking on stackframe
 *
 */
public class TestManyThreads {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		final Random random = new Random();
		for (int i = 0; i < 200; i++) {
			new Thread() {

				public void run() {
					try {
						if (Thread.currentThread().getName().endsWith("-122"))
						{
							for (int i=0; i<1000; i++)				// BREAKPOINT HERE
								System.out.println("hai");
						}
								
								
						if (Thread.currentThread().getName().endsWith("-150")																			
								|| Thread.currentThread().getName().endsWith(
										"-24"))
						{
							System.out.println(Thread.currentThread().getName());
							int sleep = random.nextInt(10000);
							Thread.sleep(sleep);
							System.out.println(Thread.currentThread().getName() + " terminated");
						}
						else
						{
							int sleep = random.nextInt(10000);								
							Thread.sleep(sleep);
							System.out.println(Thread.currentThread().getName() + " terminated");
						}
					} catch (Exception e) {
					}
				}
			}.start();
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
			}
		}

	}
}

