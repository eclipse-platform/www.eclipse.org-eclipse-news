package test.launch.options;

public class FooPiggyBackTab extends FooTab {

	
	public String getName() {
		return "Foo Piggyback Tab";
	}
}
