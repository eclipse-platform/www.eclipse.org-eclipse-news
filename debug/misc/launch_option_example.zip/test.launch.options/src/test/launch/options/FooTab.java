package test.launch.options;
import java.util.HashSet;
import java.util.Set;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.debug.core.DebugPlugin;
import org.eclipse.debug.core.ILaunchConfiguration;
import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
import org.eclipse.debug.internal.core.LaunchConfiguration;
import org.eclipse.debug.ui.AbstractOptionLaunchConfigurationTab;
import org.eclipse.jdt.internal.debug.ui.SWTUtil;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;


public class FooTab extends AbstractOptionLaunchConfigurationTab {

	protected Button fButt = null;
	protected Set fOptions = null;

	/**
	 * @see org.eclipse.debug.ui.ILaunchConfigurationTab#createControl(org.eclipse.swt.widgets.Composite)
	 */
	public void createControl(Composite parent) {
		Composite comp = SWTUtil.createComposite(parent, parent.getFont(), 1, 1, GridData.FILL_BOTH);
		fButt = SWTUtil.createCheckButton(comp, "Check me to retarget the launch delegate.", false);
		fButt.addSelectionListener(new SelectionListener() {

			public void widgetDefaultSelected(SelectionEvent e) {
			}

			public void widgetSelected(SelectionEvent e) {
				updateLaunchConfigurationDialog();
			}
			
		});
		DebugPlugin.getDefault().getLaunchManager().addLaunchConfigurationListener(this);
		setControl(comp);
	}
	
	/**
	 * @see org.eclipse.debug.ui.AbstractOptionLaunchConfigurationTab#getOption()
	 */
	public Set getOptions() {
		if(fOptions == null) {
			fOptions = new HashSet();
			fOptions.add("fooapplet");
			fOptions.add("test");
			fOptions.add("multi");
		}
		return fOptions;
	}
	
	/**
	 * @see org.eclipse.debug.ui.ILaunchConfigurationTab#getName()
	 */
	public String getName() {
		return "Foo Tab";
	}

	/**
	 * @see org.eclipse.debug.ui.ILaunchConfigurationTab#initializeFrom(org.eclipse.debug.core.ILaunchConfiguration)
	 */
	public void initializeFrom(ILaunchConfiguration configuration) {
		try {
			Set options = configuration.getAttribute(LaunchConfiguration.ATTR_LAUNCH_OPTIONS, (Set)null);
			if(options != null) {
				fButt.setSelection(options.containsAll(getOptions()));
			}
			else {
				fButt.setSelection(false);
			}
		}
		catch(CoreException ce) {}
	}

	/**
	 * @see org.eclipse.debug.ui.ILaunchConfigurationTab#performApply(org.eclipse.debug.core.ILaunchConfigurationWorkingCopy)
	 */
	public void performApply(ILaunchConfigurationWorkingCopy configuration) {
		if(isDirty()) {
			if(fButt.getSelection()) {
				configuration.addOptions(getOptions());
			}
			else {
				configuration.removeOptions(getOptions());
			}
		}
	}

	/**
	 * @see org.eclipse.debug.ui.ILaunchConfigurationTab#setDefaults(org.eclipse.debug.core.ILaunchConfigurationWorkingCopy)
	 */
	public void setDefaults(ILaunchConfigurationWorkingCopy configuration) {}

	/**
	 * @see org.eclipse.debug.ui.AbstractOptionLaunchConfigurationTab#updateOptionControls(java.util.List)
	 */
	public void updateOptionControls(Set options) {
		boolean sel = fButt.getSelection();
		if(!sel & options.containsAll(getOptions())) {
			fButt.setSelection(true);
		}
		else if(sel & !options.containsAll(getOptions())) {
			fButt.setSelection(false);
		}	
	}
}
