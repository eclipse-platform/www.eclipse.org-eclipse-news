package test.launch.options;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.debug.core.ILaunchConfiguration;
import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
import org.eclipse.debug.internal.core.LaunchConfiguration;
import org.eclipse.jdt.internal.debug.ui.SWTUtil;
import org.eclipse.jdt.internal.debug.ui.launcher.AbstractJavaMainTab;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;


public class FooTab extends AbstractJavaMainTab {

	private Button fButt = null;

	public boolean canSave() {
		return true;
	}

	public void createControl(Composite parent) {
		Composite comp = SWTUtil.createComposite(parent, parent.getFont(), 1, 1, GridData.FILL_BOTH);
		fButt = SWTUtil.createCheckButton(comp, "Check me to retarget the Java App delegate to the Java Applet delegate.", false);
		fButt.addSelectionListener(new SelectionListener() {

			public void widgetDefaultSelected(SelectionEvent e) {
			}

			public void widgetSelected(SelectionEvent e) {
				setDirty(true);
				updateLaunchConfigurationDialog();
			}
			
		});
		setControl(comp);
	}

	public String getName() {
		return "Foo Tab";
	}

	public void initializeFrom(ILaunchConfiguration configuration) {
		try {
			fButt.setSelection((configuration.getAttribute(LaunchConfiguration.ATTR_LAUNCH_OPTIONS, (String)null) == null ? false : true));
		}
		catch(CoreException ce) {}
	}

	public boolean isValid(ILaunchConfiguration launchConfig) {
		return true;
	}

	public void performApply(ILaunchConfigurationWorkingCopy configuration) {
		if(fButt.getSelection()) {
			configuration.setOptions(new String[] {"fooapplet"});
		}
		else {
			configuration.setOptions(null);
		}
	}

	public void setDefaults(ILaunchConfigurationWorkingCopy configuration) {
	}

}
