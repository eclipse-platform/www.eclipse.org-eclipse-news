/*******************************************************************************
 * Copyright (c) 2009 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.debug.examples.counter.model;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.debug.core.DebugEvent;
import org.eclipse.debug.core.DebugException;
import org.eclipse.debug.core.model.IBreakpoint;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.debug.core.model.IStackFrame;
import org.eclipse.debug.core.model.IThread;
import org.eclipse.debug.examples.counter.breakpoints.LimitBreakpoint;

/**
 * Thread for the counting debug model example.
 */
public class CounterThread extends CounterDebugElement implements IThread {
	
	/**
	 * Bounds of the loop counting - the thread counts from MIN to MAX
	 */
	public static final int MIN_COUNTER = 1;
	public static final int MAX_COUNTER = 100;
	
	/**
	 * Possible thread states
	 */
	private static final int TERMINATED = 0;
	private static final int RUNNING = 1;
	private static final int STEPPING = 2;
	private static final int SUSPENDED = 3;
	
	/**
	 * Possible events
	 */
	private static final int EVENT_BREAKPOINT = 4;
	private static final int EVENT_TERMINATED = 6;
	private static final int EVENT_SUSPENDED = 7;
	private static final int EVENT_NONE = 8;
	
	/**
	 * The time it takes to execute one instruction
	 */
	private static final int INSTRUCTION_TIME = 100;
		
	/**
	 * The threads current state, initialized to RUNNING.
	 */
	private int fState = RUNNING;
	
	/**
	 * The next state requested by the client (i.e. to suspend, step, or terminate)
	 */
	private int fRequest = RUNNING;
		
	/**
	 * The breakpoint that was hit during the last instruction, or <code>null</code> if none.
	 */
	private IBreakpoint fBreakpoint = null;
	
	/**
	 * The current count value
	 */
	int fCount = MIN_COUNTER - 1;
	
	/**
	 * Separate thread to perform execution or stepping in (executes instructions)
	 */
	private Thread fExecutionThread;
	
	/**
	 * Simulates a step over - executes the next instruction and fires events.
	 */
	class StepOver implements Runnable {
		/* (non-Javadoc)
		 * @see java.lang.Runnable#run()
		 */
		public void run() {
			//#ifdef ex_ec2009
			// TODO: --- Exercise 2 ---
			//
			// Simulate a step over:
			//   * update thread state to STEPPING
			//   * fire an event to indicate the step has started
			//   * execute the next instruction
			//   * update thread state to SUSPENDED
			//   * fire an event to indicate the step has completed
			// For hints, look at the code that simulates a resume.	
			//#else
			synchronized (CounterThread.this) {
				fState = STEPPING;
			}
			fireResumeEvent(DebugEvent.STEP_OVER);
			int event = executeNextInstruction();
			int detail = DebugEvent.UNSPECIFIED;
			synchronized (CounterThread.this) {
				// update state
				switch (event) {
					case EVENT_BREAKPOINT:
						fState = SUSPENDED;
						detail = DebugEvent.BREAKPOINT;
						break;
					case EVENT_NONE:
						fState = SUSPENDED;
						detail = DebugEvent.STEP_END;
						break;
					case EVENT_TERMINATED:
						fState = TERMINATED;
						break;
					case EVENT_SUSPENDED:
						fState = SUSPENDED;
						detail = DebugEvent.CLIENT_REQUEST;
						break;
					}
			}
			switch (fState) {
				case SUSPENDED:
					fireSuspendEvent(detail);
					break;
				case TERMINATED:
					fireTerminateEvent();
					CounterDebugTarget target = (CounterDebugTarget)getDebugTarget();
					target.terminated();
					break;
			}
			//#endif
		}
	}	
	
	/**
	 * Simulates a running thread until a breakpoint is hit, a suspend
	 * request is received, a step ends, or terminated. 
	 */
	class Resume implements Runnable {
		/* (non-Javadoc)
		 * @see java.lang.Runnable#run()
		 */
		public void run() {
			synchronized (CounterThread.this) {
				fState = RUNNING;
			}
			fireResumeEvent(DebugEvent.CLIENT_REQUEST);
			int event = EVENT_NONE;
			while (event == EVENT_NONE) {
				event = executeNextInstruction();
			}
			int detail = DebugEvent.UNSPECIFIED;
			synchronized (CounterThread.this) {
				// update state
				switch (event) {
					case EVENT_BREAKPOINT:
						fState = SUSPENDED;
						detail = DebugEvent.BREAKPOINT;
						break;
					case EVENT_TERMINATED:
						fState = TERMINATED;
						break;
					case EVENT_SUSPENDED:
						fState = SUSPENDED;
						detail = DebugEvent.CLIENT_REQUEST;
						break;
					}
			}
			switch (fState) {
				case SUSPENDED:
					fireSuspendEvent(detail);
					break;
				case TERMINATED:
					fireTerminateEvent();
					CounterDebugTarget target = (CounterDebugTarget)getDebugTarget();
					target.terminated();
					break;
			}
		}
	}

	/**
	 * Constructs a thread in the given target.
	 * 
	 * @param target debug target
	 */
	public CounterThread(IDebugTarget target) {
		super(target);
		fExecutionThread = new Thread(new Resume());
		fExecutionThread.start();
		fireCreationEvent();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.IThread#getBreakpoints()
	 */
	public IBreakpoint[] getBreakpoints() {
		if (fBreakpoint == null) {
			return new IBreakpoint[0];
		}
		return new IBreakpoint[]{fBreakpoint};
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.IThread#getName()
	 */
	public String getName() throws DebugException {
		return "Counting Thread";
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.IThread#getPriority()
	 */
	public int getPriority() throws DebugException {
		return 0;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.IThread#getStackFrames()
	 */
	public IStackFrame[] getStackFrames() throws DebugException {
		//#ifdef ex_ec2009
		// TODO: --- Exercise 2 ---
		//
		// Retrieve the stack frames for this thread. A thread only has stack
		// frames when it is suspended. The number of stack frames is based on the
		// the current count (fCount) value, and the top frame on the stack has the
		// highest value.
		//
//#		return null;		
		//#else
		synchronized (this) {
			if (isSuspended()) {
				IStackFrame[] frames = new IStackFrame[fCount];
				for (int i = 0; i < frames.length; i++) {
					frames[i] = new CounterStackFrame(this, fCount - i);
					
				}
				return frames;
			}
		}
		return new IStackFrame[0];
		//#endif
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.IThread#getTopStackFrame()
	 */
	public IStackFrame getTopStackFrame() throws DebugException {
		//#ifdef ex_ec2009
		// TODO: --- Exercise 2 ---
		//
		// Retrieve the top stack frame. A thread only has stack frames when it is
		// suspended. The top frame on the stack contains the current count value (fCount).
		//
		//#else
		synchronized (this) {
			if (isSuspended()) {
				return new CounterStackFrame(this, fCount);
			}
		}
		//#endif
		return null;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.IThread#hasStackFrames()
	 */
	public boolean hasStackFrames() throws DebugException {
		//#ifdef ex_ec2009
		// TODO: --- Exercise 2 ---
		//
		// A thread only has stack frames when it is suspended.
		//
//#		return false;		
		//#else
		return isSuspended();
		//#endif
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.ISuspendResume#canResume()
	 */
	public synchronized boolean canResume() {
		return isSuspended();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.ISuspendResume#canSuspend()
	 */
	public synchronized boolean canSuspend() {
		return !isTerminated() && !isSuspended();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.ISuspendResume#isSuspended()
	 */
	public synchronized boolean isSuspended() {
		return fState == SUSPENDED;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.ISuspendResume#resume()
	 */
	public void resume() throws DebugException {
		synchronized (this) {
			fRequest = RUNNING;
			fExecutionThread = new Thread(new Resume());
			fExecutionThread.start();
		}
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.ISuspendResume#suspend()
	 */
	public void suspend() throws DebugException {
		synchronized (this) {
			fRequest = SUSPENDED;
			fExecutionThread.interrupt();	
		}
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.IStep#canStepInto()
	 */
	public boolean canStepInto() {
		return false;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.IStep#canStepOver()
	 */
	public boolean canStepOver() {
		return isSuspended();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.IStep#canStepReturn()
	 */
	public boolean canStepReturn() {
		return false;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.IStep#isStepping()
	 */
	public synchronized boolean isStepping() {
		return fState == STEPPING;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.IStep#stepInto()
	 */
	public void stepInto() throws DebugException {
		notSupported("Step into not supported", null);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.IStep#stepOver()
	 */
	public void stepOver() throws DebugException {
		synchronized (this) {
			fRequest = STEPPING;
			fExecutionThread = new Thread(new StepOver());
			fExecutionThread.start();
		}
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.IStep#stepReturn()
	 */
	public void stepReturn() throws DebugException {
		notSupported("Step return not supported", null);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.ITerminate#canTerminate()
	 */
	public boolean canTerminate() {
		return !isTerminated();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.ITerminate#isTerminated()
	 */
	public synchronized boolean isTerminated() {
		return fState == TERMINATED;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.ITerminate#terminate()
	 */
	public void terminate() throws DebugException {
		synchronized (this) {
			fRequest = TERMINATED;
			if (isSuspended()) {
				// run to termination
				fExecutionThread = new Thread(new Resume());
				fExecutionThread.start();
			} else {
				fExecutionThread.interrupt();
			}
		}
	}
	
	/**
	 * Executes the next instruction (sleeps and increments a counter) and returns any event
	 * that occurred during the execution:
	 * <ul>
	 * <li>EVENT_TERMINATED - execution was terminated</li>
	 * <li>EVENT_SUSPENDED - execution was suspended</li>
	 * <li>EVENT_BREAKPOINT - execution hit a breakpoint</li>
	 * <li>EVENT_NONE - instruction completed normally</li>
	 * </ul>
	 *  
	 * @return event code
	 * @throws InterruptedException
	 */
	private int executeNextInstruction() {
		fBreakpoint = null;
		if (fRequest == TERMINATED) {
			return EVENT_TERMINATED;
		}			
		try {
			Thread.sleep(INSTRUCTION_TIME);
		} catch (InterruptedException e) {
			switch (fRequest) {
				case TERMINATED:
					return EVENT_TERMINATED;
				case SUSPENDED:
					return EVENT_SUSPENDED;
			}
		}
		fCount++;
		if (fCount > MAX_COUNTER) {
			fCount = MIN_COUNTER;
		}
		//#ifdef ex_ec2009
		// TODO: --- Exercise 3 ---
		//
		// Check if an installed breakpoint has been hit. This thread's target maintains
		// a collection of installed breakpoints (CounterDebugTarget#getInstalledBreakpoints()).
		// If the current counter value matches any breakpoint limit, execution should
		// suspend by returning EVENT_BREAKPOINT from this method.
		// 
		//#else	
		LimitBreakpoint[] breakpoints = ((CounterDebugTarget)getDebugTarget()).getInstalledBreakpoints();
		for (int i = 0; i < breakpoints.length; i++) {
			LimitBreakpoint breakpoint = breakpoints[i];
			try {
				if (breakpoint.isEnabled() && fCount == breakpoint.getLimit()) {
					fBreakpoint = breakpoint;
					return EVENT_BREAKPOINT;
				}
			} catch (CoreException e) {
			}
		}
		//#endif
		return EVENT_NONE;
	}

}
