/*******************************************************************************
 * Copyright (c) 2009 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.debug.examples.counter.model;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IMarkerDelta;
import org.eclipse.debug.core.DebugException;
import org.eclipse.debug.core.DebugPlugin;
import org.eclipse.debug.core.IBreakpointManager;
import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.model.IBreakpoint;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.debug.core.model.IMemoryBlock;
import org.eclipse.debug.core.model.IProcess;
import org.eclipse.debug.core.model.IThread;
import org.eclipse.debug.examples.counter.breakpoints.LimitBreakpoint;

/**
 * Debug target for the counter model.
 */
public class CounterDebugTarget extends CounterDebugElement implements IDebugTarget {
	
	/**
	 * The single thread in this target
	 */
	private IThread fThread;
	
	/**
	 * The launch this target is part of;
	 */
	private ILaunch fLaunch;
	
	/**
	 * List of installed breakpoints
	 */
	private List fBreakpoints = new ArrayList();

	/**
	 * Constructs the counting target with a single thread and installs deferred breakpoints.
	 */
	public CounterDebugTarget(ILaunch launch) {
		super(null);
		fLaunch = launch;
		fThread = new CounterThread(this);
		IBreakpointManager manager = DebugPlugin.getDefault().getBreakpointManager();
		manager.addBreakpointListener(this);
		fireCreationEvent();
		//#ifdef ex_ec2009
		// TODO: --- Exercise 3 ---
		//
		// Install deferred breakpoints - i.e. and existing LimitBreakpoint's. Retrieve
		// existing breakpoints from the breakpoint manager.
		// 
		//#else	
		IBreakpoint[] breakpoints = manager.getBreakpoints(getModelIdentifier());
		for (int i = 0; i < breakpoints.length; i++) {
			breakpointAdded(breakpoints[i]);
		}
		//#endif
	}
	
	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.DebugElement#getDebugTarget()
	 */
	public IDebugTarget getDebugTarget() {
		return this;
	}
	
	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.DebugElement#getLaunch()
	 */
	public ILaunch getLaunch() {
		return fLaunch;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.IDebugTarget#getName()
	 */
	public String getName() throws DebugException {
		return "Counting Target";
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.IDebugTarget#getProcess()
	 */
	public IProcess getProcess() {
		return null;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.IDebugTarget#getThreads()
	 */
	public IThread[] getThreads() throws DebugException {
		if (isTerminated()) {
			return new IThread[0];
		}
		return new IThread[]{fThread};
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.IDebugTarget#hasThreads()
	 */
	public boolean hasThreads() throws DebugException {
		return true;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.IDebugTarget#supportsBreakpoint(org.eclipse.debug.core.model.IBreakpoint)
	 */
	public boolean supportsBreakpoint(IBreakpoint breakpoint) {
		return breakpoint instanceof LimitBreakpoint;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.ITerminate#canTerminate()
	 */
	public boolean canTerminate() {
		return fThread.canTerminate();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.ITerminate#isTerminated()
	 */
	public boolean isTerminated() {
		return fThread.isTerminated();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.ITerminate#terminate()
	 */
	public void terminate() throws DebugException {
		fThread.terminate();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.ISuspendResume#canResume()
	 */
	public boolean canResume() {
		return fThread.canResume();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.ISuspendResume#canSuspend()
	 */
	public boolean canSuspend() {
		return fThread.canSuspend();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.ISuspendResume#isSuspended()
	 */
	public boolean isSuspended() {
		return fThread.isSuspended();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.ISuspendResume#resume()
	 */
	public void resume() throws DebugException {
		fThread.resume();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.ISuspendResume#suspend()
	 */
	public void suspend() throws DebugException {
		fThread.suspend();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.IBreakpointListener#breakpointAdded(org.eclipse.debug.core.model.IBreakpoint)
	 */
	public void breakpointAdded(IBreakpoint breakpoint) {
		//#ifdef ex_ec2009
		// TODO: --- Exercise 3 ---
		//
		// Install breakpoints applicable to this target - i.e. only LimitBreakpoint's.
		// Breakpoints are installed by adding them this target's breakpoint collection.
		// When an instruction is executed (in CounterThread#executeNextInstruction()), 
		// the thread checks if a breakpoint in this target's breakpoint collection has
		// been hit.
		// 
		//#else		
		if (breakpoint instanceof LimitBreakpoint) {
			synchronized (fBreakpoints) {
				fBreakpoints.add(breakpoint);
			}
		}
		//#endif
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.IBreakpointListener#breakpointChanged(org.eclipse.debug.core.model.IBreakpoint, org.eclipse.core.resources.IMarkerDelta)
	 */
	public void breakpointChanged(IBreakpoint breakpoint, IMarkerDelta delta) {
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.IBreakpointListener#breakpointRemoved(org.eclipse.debug.core.model.IBreakpoint, org.eclipse.core.resources.IMarkerDelta)
	 */
	public void breakpointRemoved(IBreakpoint breakpoint, IMarkerDelta delta) {
		//#ifdef ex_ec2009
		// TODO: --- Exercise 3 ---
		//
		// Uninstall breakpoints applicable to this target - i.e. only LimitBreakpoint's.
		// 
		//#else			
		if (breakpoint instanceof LimitBreakpoint) {
			synchronized (fBreakpoints) {
				fBreakpoints.remove(breakpoint);
			}
		}
		//#endif
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.IDisconnect#canDisconnect()
	 */
	public boolean canDisconnect() {
		return false;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.IDisconnect#disconnect()
	 */
	public void disconnect() throws DebugException {
		notSupported("disconnect not supported", null);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.IDisconnect#isDisconnected()
	 */
	public boolean isDisconnected() {
		return false;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.IMemoryBlockRetrieval#getMemoryBlock(long, long)
	 */
	public IMemoryBlock getMemoryBlock(long startAddress, long length) throws DebugException {
		return null;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.core.model.IMemoryBlockRetrieval#supportsStorageRetrieval()
	 */
	public boolean supportsStorageRetrieval() {
		return false;
	}

	/**
	 * Returns a collection of all breakpoints currently installed.
	 * 
	 * @return installed breakpoints
	 */
	LimitBreakpoint[] getInstalledBreakpoints() {
		return (LimitBreakpoint[]) fBreakpoints.toArray(new LimitBreakpoint[fBreakpoints.size()]);
	}
	
	/**
	 * Cleans up on termination:
	 * <ul>
	 * <li>Removes itself as a breakpoint listener from the breakpoint manager.</li>
	 * <li>Clears all breakpoints known to this target.</li>
	 * <li>Fires a terminate event.</li>
	 * </ul>
	 */
	void terminated() {
		DebugPlugin.getDefault().getBreakpointManager().removeBreakpointListener(this);
		fBreakpoints.clear();
		fireTerminateEvent();
	}
}
