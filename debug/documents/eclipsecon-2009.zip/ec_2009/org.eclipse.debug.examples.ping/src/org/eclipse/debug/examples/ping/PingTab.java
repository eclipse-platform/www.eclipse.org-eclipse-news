/*******************************************************************************
 * Copyright (c) 2009 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.debug.examples.ping;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.debug.core.ILaunchConfiguration;
import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
import org.eclipse.debug.ui.AbstractLaunchConfigurationTab;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

/**
 * Tab that specifies an address to ping. A text widget is provided for the user to
 * enter an address.
 */
public class PingTab extends AbstractLaunchConfigurationTab {
	
	/**
	 * Test widget for address
	 */
	private Text fAddress;

	/* (non-Javadoc)
	 * @see org.eclipse.debug.ui.ILaunchConfigurationTab#createControl(org.eclipse.swt.widgets.Composite)
	 */
	public void createControl(Composite parent) {
		Font font = parent.getFont();
		
		Composite comp = new Composite(parent, SWT.NONE);
		setControl(comp);
		GridLayout topLayout = new GridLayout();
		topLayout.verticalSpacing = 0;
		topLayout.numColumns = 2;
		comp.setLayout(topLayout);
		comp.setFont(font);
		
		createVerticalSpacer(comp, 3);
		
		Label label = new Label(comp, SWT.NONE);
		label.setText("&Address:");
		GridData gd = new GridData(GridData.BEGINNING);
		label.setLayoutData(gd);
		label.setFont(font);
		
		fAddress = new Text(comp, SWT.SINGLE | SWT.BORDER);
		gd = new GridData(GridData.FILL_HORIZONTAL);
		fAddress.setLayoutData(gd);
		fAddress.setFont(font);
		fAddress.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				updateLaunchConfigurationDialog();
			}
		});

	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.ui.ILaunchConfigurationTab#getName()
	 */
	public String getName() {
		return "Ping";
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.ui.ILaunchConfigurationTab#initializeFrom(org.eclipse.debug.core.ILaunchConfiguration)
	 */
	public void initializeFrom(ILaunchConfiguration configuration) {
		//#ifdef ex_ec2009
		// TODO: --- Exercise 1 ---
		//
		// This method is called to initialize the tab widgets/controls based on attributes
		// persisted in a launch configuration. In this case the address/domain name to be
		// ping'ed should be read from the configuration and placed in the address text control.
		//
		// Note that the PingLaunchDelegate class defines the address attribute key. Should there
		// an error reading the configuration, an error message can be displayed in the launch
		// dialog, via #setErrorMessage(String).
		//#else
		try {
			fAddress.setText(configuration.getAttribute(PingLaunchDelegate.PING_ADDRESS, ""));
		} catch (CoreException e) {
			setErrorMessage(e.getMessage());
		}
		//#endif
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.ui.ILaunchConfigurationTab#performApply(org.eclipse.debug.core.ILaunchConfigurationWorkingCopy)
	 */
	public void performApply(ILaunchConfigurationWorkingCopy configuration) {
		//#ifdef ex_ec2009
		// TODO: --- Exercise 1 ---
		//
		// This method is called to write settings from the tab widgets/controls to the launch
		// configuration being edited. In this case the address/domain name to be
		// ping'ed should be set back to the configuration (working copy).
		//
		// This method is called each time the user modifies the address text, since the modification
		// listener provided calls updateLaunchConfigurationDialog(). We could perform extra
		// validation on the address/domain name by overriding #isValid(...).
		//
		// Note that the PingLaunchDelegate class defines the address attribute key.
		//#else
		String address = fAddress.getText().trim();
		if (address.length() == 0) {
			address = null;
		}
		configuration.setAttribute(PingLaunchDelegate.PING_ADDRESS, address);
		//#endif
	}

	/* (non-Javadoc)
	 * @see org.eclipse.debug.ui.ILaunchConfigurationTab#setDefaults(org.eclipse.debug.core.ILaunchConfigurationWorkingCopy)
	 */
	public void setDefaults(ILaunchConfigurationWorkingCopy configuration) {
	}

}
